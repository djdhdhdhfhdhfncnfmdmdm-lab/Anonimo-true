// Loja Roblox — servidor único. Requer Node 18+.
// Para produção no Render, use DATABASE_URL (Postgres) para não perder dados em reinícios.
// Variáveis: GOOGLE_CLIENT_ID, MP_TOKEN, ADMIN_EMAIL, STORE_NAME, DATABASE_URL,
//            MP_PRIVATE_KEY (somente se o Payouts da sua conta exigir assinatura),
//            MP_PAYOUTS_ENABLED=1 para habilitar saques automáticos.

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { OAuth2Client } = require('google-auth-library');
const { Pool } = require('pg');

const {
  GOOGLE_CLIENT_ID: CID,
  MP_TOKEN,
  ADMIN_EMAIL = '',
  MP_PRIVATE_KEY,
  STORE_NAME = 'Loja Roblox',
  DATABASE_URL,
  MP_PAYOUTS_ENABLED = '0',
  PORT = 3000
} = process.env;

if (!CID) console.warn('AVISO: GOOGLE_CLIENT_ID não configurado.');
if (!MP_TOKEN) console.warn('AVISO: MP_TOKEN não configurado.');

const google = new OAuth2Client(CID);
const pool = DATABASE_URL ? new Pool({ connectionString: DATABASE_URL, ssl: { rejectUnauthorized: false } }) : null;
const dbFile = path.join(__dirname, 'db.json');
let mem = { cats: [], prods: [], orders: [], tickets: [], out: [], settings: {} };
try { mem = { ...mem, ...JSON.parse(fs.readFileSync(dbFile, 'utf8')) }; } catch {}

async function initDb() {
  if (!pool) return;
  await pool.query(`
    CREATE TABLE IF NOT EXISTS loja_state (
      id INTEGER PRIMARY KEY,
      data JSONB NOT NULL,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS loja_sessions (
      token_hash TEXT PRIMARY KEY,
      email TEXT NOT NULL,
      name TEXT,
      picture TEXT,
      expires_at TIMESTAMPTZ NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS loja_sessions_expires_idx ON loja_sessions(expires_at);
  `);
  const r = await pool.query('SELECT data FROM loja_state WHERE id=1');
  if (!r.rowCount) await pool.query('INSERT INTO loja_state(id,data) VALUES(1,$1)', [mem]);
  else mem = { ...mem, ...r.rows[0].data };
}

async function loadDb() {
  if (!pool) return mem;
  const r = await pool.query('SELECT data FROM loja_state WHERE id=1');
  return r.rowCount ? r.rows[0].data : mem;
}

async function saveDb(next = mem) {
  mem = next;
  if (!pool) {
    fs.writeFileSync(dbFile, JSON.stringify(mem));
    return;
  }
  await pool.query(
    'INSERT INTO loja_state(id,data,updated_at) VALUES(1,$1,NOW()) ON CONFLICT(id) DO UPDATE SET data=EXCLUDED.data,updated_at=NOW()',
    [mem]
  );
}

const uid = () => crypto.randomUUID();
const hash = s => crypto.createHash('sha256').update(s).digest('hex');
const cleanEmail = s => String(s || '').trim().toLowerCase();

async function MP(endpoint, options = {}) {
  if (!MP_TOKEN) return { ok: false, j: { message: 'MP_TOKEN não configurado' } };
  const r = await fetch('https://api.mercadopago.com' + endpoint, {
    ...options,
    headers: { Authorization: 'Bearer ' + MP_TOKEN, 'Content-Type': 'application/json', ...(options.headers || {}) }
  });
  return { ok: r.ok, status: r.status, j: await r.json().catch(() => ({})) };
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on('data', c => { size += c.length; if (size > 25e6) { reject(Error('Arquivo grande demais')); req.destroy(); return; } chunks.push(c); });
    req.on('end', () => { try { const s = Buffer.concat(chunks).toString(); resolve(s ? JSON.parse(s) : {}); } catch (e) { reject(Error('JSON inválido')); } });
    req.on('error', reject);
  });
}

async function createSession(user) {
  const raw = crypto.randomBytes(32).toString('base64url');
  await pool.query(
    'INSERT INTO loja_sessions(token_hash,email,name,picture,expires_at) VALUES($1,$2,$3,$4,NOW()+INTERVAL \'30 days\')',
    [hash(raw), cleanEmail(user.email), user.name || '', user.picture || '']
  );
  return raw;
}

async function userFromSession(req) {
  const cookie = String(req.headers.cookie || '').split(';').map(x => x.trim()).find(x => x.startsWith('loja_session='));
  if (!cookie) return null;
  const token = cookie.slice('loja_session='.length);
  if (!token) return null;
  if (pool) {
    const r = await pool.query('SELECT email,name,picture FROM loja_sessions WHERE token_hash=$1 AND expires_at>NOW()', [hash(token)]);
    return r.rowCount ? r.rows[0] : null;
  }
  // Fallback local: sessões em memória (use DATABASE_URL em produção).
  return sessions.get(hash(token)) || null;
}

const sessions = new Map();

async function authenticate(req) {
  const session = await userFromSession(req);
  if (session) return session;
  const bearer = String(req.headers.authorization || '');
  if (!bearer.startsWith('Bearer ')) return null;
  try {
    const ticket = await google.verifyIdToken({ idToken: bearer.slice(7), audience: CID });
    const p = ticket.getPayload();
    if (!p?.email || p.email_verified === false) return null;
    return { email: cleanEmail(p.email), name: p.name || '', picture: p.picture || '' };
  } catch { return null; }
}

async function requireUser(req, res) {
  const u = await authenticate(req);
  if (!u) { send(res, 401, { error: 'Entre com o Google' }); return null; }
  return u;
}

function send(res, code, obj, headers = {}) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(JSON.stringify(obj));
}

const rate = (id) => {
  const s = mem.orders.filter(o => o.pid === id && o.stars).map(o => o.stars);
  return { n: s.length, avg: s.length ? s.reduce((a,b)=>a+b,0) / s.length : 0 };
};
const pub = p => ({
  id:p.id, cat:p.cat, title:p.title, desc:p.desc, imgs:p.imgs || [], rate:rate(p.id),
  vars:(p.vars || []).map(v => ({ id:v.id, name:v.name, price:v.price, off:!!v.sold || v.until>Date.now() }))
});
const paidSales = () => mem.orders.filter(o => o.status === 'paid');
const withdrawn = () => mem.out.filter(o => ['paid','processed','success'].includes(o.status || ''));
const reservedWithdrawals = () => mem.out.filter(o => !['rejected','error','canceled','cancelled','refunded'].includes(o.status || ''));
const saldo = () => +(paidSales().reduce((a,o)=>a + (+o.net || 0),0) - reservedWithdrawals().reduce((a,o)=>a + (+o.amount || 0),0)).toFixed(2);
const soldTotal = () => +paidSales().reduce((a,o)=>a + (+o.net || 0),0).toFixed(2);
const withdrawnTotal = () => +withdrawn().reduce((a,o)=>a + (+o.amount || 0),0).toFixed(2);

async function check(o) {
  if (o.status !== 'pending') return;
  const { j } = await MP('/v1/payments/' + encodeURIComponent(o.mp));
  const p = mem.prods.find(x => x.id === o.pid), v = p?.vars?.find(x => x.id === o.vid);
  if (j.status === 'approved') {
    Object.assign(o, {
      status:'paid', net:j.transaction_details?.net_received_amount ?? o.amount,
      title:(p?.title || 'Conta') + (v?.name ? ' — '+v.name : ''), login:v?.login, senha:v?.senha,
      paidAt:Date.now()
    });
    if (v) v.sold = 1;
    await saveDb();
  } else if (['cancelled','expired','rejected'].includes(j.status)) {
    o.status='dead'; if (v?.by === o.email) { v.until=0; delete v.by; } await saveDb();
  }
}

function admin(u) { return cleanEmail(u.email) === cleanEmail(ADMIN_EMAIL) && !!ADMIN_EMAIL; }

const S = {
  '/': ['loja.html','text/html; charset=utf-8'],
  '/editor': ['editor.html','text/html; charset=utf-8'],
  '/logo.jpg': ['logo.jpg','image/jpeg']
};

function corsHeaders(req){
  const origin = req.headers.origin || process.env.FRONTEND_URL || '*';
  return {
    'Access-Control-Allow-Origin': origin || '*',
    'Access-Control-Allow-Credentials': 'true',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Vary': 'Origin'
  };
}

async function route(req, res) {
  res._cors = corsHeaders(req);
  if (req.method === 'OPTIONS') {
    res.writeHead(204, res._cors);
    return res.end();
  }
  const { pathname:p, searchParams:q } = new URL(req.url, 'http://localhost');
  if (!p.startsWith('/api/')) {
    const f = S[p];
    if (!f) { res.writeHead(404); return res.end('Não encontrado'); }
    try { res.writeHead(200, {'Content-Type':f[1], 'Cache-Control':'no-store'}); return res.end(fs.readFileSync(path.join(__dirname,f[0]))); }
    catch { res.writeHead(404); return res.end('Arquivo não encontrado'); }
  }

  try {
    if (p === '/api/auth' && req.method === 'POST') {
      const b = await readBody(req);
      if (!b.credential) return send(res,400,{error:'Credencial Google ausente'});
      if (!CID) return send(res,500,{error:'GOOGLE_CLIENT_ID não configurado'});
      let payload;
      try { payload=(await google.verifyIdToken({idToken:b.credential,audience:CID})).getPayload(); }
      catch { return send(res,401,{error:'Login Google inválido ou expirado'}); }
      if (!payload?.email || payload.email_verified === false) return send(res,401,{error:'E-mail Google não verificado'});
      if (pool) {
        const token=await createSession(payload);
        return send(res,200,{email:cleanEmail(payload.email),name:payload.name||'',picture:payload.picture||''},{'Set-Cookie':`loja_session=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=2592000`});
      }
      const raw=crypto.randomBytes(32).toString('base64url'); sessions.set(hash(raw),{email:cleanEmail(payload.email),name:payload.name||'',picture:payload.picture||''});
      return send(res,200,{email:cleanEmail(payload.email),name:payload.name||'',picture:payload.picture||''},{'Set-Cookie':`loja_session=${raw}; Path=/; HttpOnly; SameSite=Lax; Max-Age=2592000`});
    }
    if (p === '/api/logout' && req.method === 'POST') {
      const c=String(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('loja_session='));
      if (c && pool) await pool.query('DELETE FROM loja_sessions WHERE token_hash=$1',[hash(c.slice(13))]);
      if (c && !pool) sessions.delete(hash(c.slice(13)));
      return send(res,200,{ok:1},{'Set-Cookie':'loja_session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0'});
    }
    if (p === '/api/catalog') return send(res,200,{cid:CID,name:mem.settings?.storeName || STORE_NAME,cats:mem.cats,prods:mem.prods.map(pub)});

    const u=await requireUser(req,res); if(!u)return;
    const b=req.method==='POST'?await readBody(req):{};

    if (p === '/api/me') return send(res,200,{email:u.email,name:u.name,picture:u.picture,admin:admin(u)});

    if (p === '/api/pay') {
      const pr=mem.prods.find(x=>x.id===b.pid), v=pr?.vars?.find(x=>x.id===b.vid);
      if(!v||v.sold||(v.until>Date.now()&&v.by!==u.email))return send(res,409,{error:'Conta indisponível'});
      const id=uid(),until=Date.now()+15*60000;
      const r=await MP('/v1/payments',{method:'POST',headers:{'X-Idempotency-Key':id},body:JSON.stringify({transaction_amount:+v.price,description:String(pr.title).slice(0,60),payment_method_id:'pix',payer:{email:u.email},date_of_expiration:new Date(until).toISOString().replace('Z','+00:00')})});
      const t=r.j.point_of_interaction?.transaction_data;
      if(!r.ok||!t)return send(res,502,{error:'Mercado Pago recusou: '+(r.j.message||'confira o MP_TOKEN')});
      Object.assign(v,{until,by:u.email});
      mem.orders.push({id,mp:r.j.id,pid:pr.id,vid:v.id,email:u.email,amount:+v.price,status:'pending',t:Date.now()});
      await saveDb();
      return send(res,200,{id,code:t.qr_code,img:t.qr_code_base64});
    }
    if (p === '/api/order') {
      const o=mem.orders.find(x=>x.id===q.get('id')&&x.email===u.email); if(!o)return send(res,404,{error:'Pedido não encontrado'});
      await check(o); return send(res,200,{status:o.status,title:o.title,login:o.login,senha:o.senha});
    }
    if (p === '/api/my') {
      for (const o of mem.orders.filter(x=>x.email===u.email&&x.status==='pending')) { try { await check(o); } catch {} }
      return send(res,200,mem.orders.filter(x=>x.email===u.email&&x.status==='paid').map(({id,title,login,senha,t,stars})=>({id,title,login,senha,t,stars})).reverse());
    }
    if (p === '/api/review') {
      const o=mem.orders.find(x=>x.id===b.id&&x.email===u.email&&x.status==='paid');
      if(o){o.stars=Math.min(5,Math.max(1,+b.stars|0));await saveDb();}
      return send(res,200,{ok:1});
    }
    if (p === '/api/ticket') {
      mem.tickets.push({id:uid(),email:u.email,kind:b.kind==='venda'?'venda':'suporte',text:String(b.text||'').slice(0,3000),t:Date.now()});
      await saveDb(); return send(res,200,{ok:1});
    }

    if(!admin(u))return send(res,403,{error:'Somente o dono da loja acessa o editor'});
    if(p==='/api/admin/data') return send(res,200,{cats:mem.cats,prods:mem.prods,sales:paidSales().slice().reverse(),tickets:mem.tickets.slice().reverse(),saldo:saldo(),soldTotal:soldTotal(),withdrawnTotal:withdrawnTotal(),withdrawals:mem.out.slice().reverse()});
    if(p==='/api/admin/settings' && req.method==='POST') {
      mem.settings={...(mem.settings||{}),storeName:String(b.storeName||STORE_NAME).slice(0,80)}; await saveDb(); return send(res,200,{ok:1});
    }
    if(p==='/api/admin/cat' && req.method==='POST') {
      if(!b.name||!b.img)return send(res,400,{error:'Informe nome e imagem'});
      mem.cats.push({id:uid(),name:String(b.name).slice(0,80),img:String(b.img),tip:String(b.tip||'').slice(0,120)});await saveDb();return send(res,200,{ok:1});
    }
    if(p==='/api/admin/prod' && req.method==='POST') {
      if(!b.title||!b.cat||!Array.isArray(b.vars)||!b.vars.length||b.vars.some(v=>!(+v.price>0)||!v.login||!v.senha))return send(res,400,{error:'Preencha categoria, título, preço, login e senha'});
      mem.prods.push({id:uid(),cat:b.cat,title:String(b.title).slice(0,120),desc:String(b.desc||'').slice(0,5000),imgs:Array.isArray(b.imgs)?b.imgs.slice(0,8):[],vars:b.vars.map(v=>({id:uid(),name:String(v.name||'').slice(0,80),price:+v.price,login:String(v.login),senha:String(v.senha)}))});
      await saveDb();return send(res,200,{ok:1});
    }
    if(p==='/api/admin/del' && req.method==='POST') {
      const k={cat:'cats',prod:'prods',ticket:'tickets'}[b.kind]; if(k)mem[k]=mem[k].filter(x=>x.id!==b.id); if(b.kind==='cat')mem.prods=mem.prods.filter(x=>x.cat!==b.id); await saveDb();return send(res,200,{ok:1});
    }
    if(p==='/api/admin/withdraw' && req.method==='POST') {
      const a=+b.amount;
      if(!(a>=1&&a<=saldo()))return send(res,400,{error:'Valor inválido ou maior que o saldo disponível'});
      if(!['cpf','cnpj','email','phone','random'].includes(String(b.type)))return send(res,400,{error:'Tipo de chave Pix inválido'});
      if(!String(b.key||'').trim())return send(res,400,{error:'Informe a chave Pix'});
      if(MP_PAYOUTS_ENABLED!=='1')return send(res,409,{error:'Saques automáticos ainda estão desativados. Ative MP_PAYOUTS_ENABLED=1 somente depois de liberar o Payouts na sua conta Mercado Pago.'});
      const id=uid();
      const body=JSON.stringify({external_reference:'saque_'+id,description:'Saque da loja',transactions:[{type:'pix',pix:{type:b.type,chave:String(b.key).trim()},amount:{currency:'BRL',value:a}}]});
      const h={'X-Idempotency-Key':id,'X-enforce-signature':MP_PRIVATE_KEY?'true':'false'};
      if(MP_PRIVATE_KEY) h['X-signature']=crypto.sign(null,Buffer.from(body),crypto.createPrivateKey(MP_PRIVATE_KEY.replace(/\\n/g,'\n'))).toString('base64');
      const r=await MP('/v1/payouts',{method:'POST',headers:h,body});
      if(!r.ok)return send(res,400,{error:'Mercado Pago recusou o saque: '+JSON.stringify(r.j).slice(0,240)});
      mem.out.push({id:r.j.id||id,amount:a,key:String(b.key).trim(),type:b.type,t:Date.now(),status:r.j.status||'created'}); await saveDb();
      return send(res,200,{saldo:saldo(),withdrawnTotal:withdrawnTotal(),status:r.j.status||'created'});
    }
    return send(res,404,{error:'Rota não encontrada'});
  } catch(e) { console.error(e); return send(res,500,{error:e.message||'Erro interno'}); }
}

initDb().then(() => http.createServer(route).listen(PORT,()=>console.log(`Loja rodando na porta ${PORT} — persistência: ${pool?'Postgres':'db.json (local)'}`))).catch(e=>{console.error('Falha ao iniciar:',e);process.exit(1)});
